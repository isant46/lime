# plugin.video.dramacool
DramaCool addon for [Kodi](https://kodi.tv/).

Install my [repository](https://github.com/groggyegg/groggyegg.github.io) to get the latest release.
